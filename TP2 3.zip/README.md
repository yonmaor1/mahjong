# mahjong
Welcome to Mahjong! Currently this is a single-player AI based mahjong. By default the player plays agains 3 AIs. Graphics are implemented with pygame.

# To Do List:
- Build endgame
- Build sidebar (actions buttons + dialog box)
- Network multiplayer (sockets?)
